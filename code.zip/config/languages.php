<?php
return [
    'en' => 'gb',
    'ar' => 'ar',
];
