<?php

use App\Http\Controllers\Admin\QuizController;
use App\Http\Controllers\Admin\SpecialityController;
use App\Http\Controllers\Admin\TypeController;
use App\Http\Controllers\API\V1\ProductController;
use App\Http\Controllers\API\V1\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::group(['prefix' => 'v1', 'middleware' => ['language']], function () {
    Route::post('/login', [UserController::class, 'login']);
    Route::post('/register', [UserController::class, 'store']);
    Route::post('forget-password', [UserController::class, 'forgetPassword']);

    //Get Route
    Route::get('profession', [UserController::class, 'profession']);
    Route::get('verify/account/{token}', [UserController::class, 'verify'])->name('verification.account');

    //Auth Route
    Route::group(['middleware' => ['auth:api', 'verified']], function () {
        //Active Level
        Route::get('active-level', [App\Http\Controllers\API\V1\QuizController::class, 'getLevel']);

        //Daily Challenge
        Route::get('daily-challenge', [App\Http\Controllers\API\V1\QuizController::class, 'getByLevel']);
        Route::post('daily-challenge', [App\Http\Controllers\API\V1\QuizController::class, 'SubmitLevelAnswer']);

        //Leader Board
        Route::get('leader-board', [App\Http\Controllers\API\V1\QuizController::class, 'getLeaderBoard']);
        //Contact us
        Route::post('contact', [UserController::class, 'contact']);
        //Profile
        Route::post('profile', [UserController::class, 'update']);

        //Products
        Route::get('brands', [ProductController::class, 'brands']);
        Route::get('brands/{brand_id}', [ProductController::class, 'products']);
        Route::get('products/{product_id}', [ProductController::class, 'details']);

        //Redeem
        Route::post('redeem', [UserController::class, 'redeem']);
    });

    Route::group(['prefix' => 'admin', 'middleware' => ["auth:api"]], function () {
        Route::apiResource('quiz', QuizController::class);
        Route::group(['prefix' => '{admin_id}'], function () {
            Route::apiResource('type', TypeController::class);
            Route::apiResource('speciality', SpecialityController::class);
            Route::apiResource('quiz', QuizController::class);
            Route::apiResource('users', \App\Http\Controllers\Admin\UserController::class);
        });
    });
});
