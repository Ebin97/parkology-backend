<?php


namespace App\Services\Interfaces;

use Illuminate\Http\Request;

interface IQuiz extends IBase
{
    function solved(Request $request);

    function getLevel(Request $request);

    function getByLevel($level);

    function checkLevel(Request $request);

    function getQuizIDsByLevel($level);
}
