<?php


namespace App\Services\Interfaces;


interface IType extends IBase
{

}
