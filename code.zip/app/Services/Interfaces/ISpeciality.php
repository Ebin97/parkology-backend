<?php


namespace App\Services\Interfaces;


interface ISpeciality extends IBase
{

}
