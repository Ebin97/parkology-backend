<?php


namespace App\Services\Interfaces;


use App\Models\User;
use Illuminate\Http\Request;

interface IUser extends IBase
{
    public function login(Request $request);

    public function updateUser(Request $request, $id);

    public function updateAllUserPassword();

    public function checkType(Request $request);

    public function uploadImage(Request $request, $user_id);

    public function contact(Request $request);

    public function checkToken($token);

    public function forget(Request $request);

}
