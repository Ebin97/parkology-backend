<?php


namespace App\Services\Interfaces;


interface IAnswer extends IBase
{

}
