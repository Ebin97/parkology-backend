<?php


namespace App\Services\Facades;


use App\Helper\_RuleHelper;
use App\Models\QuizAnswer;
use App\Services\Interfaces\IAnswer;

class FAnswer extends FBase implements IAnswer
{
    public function __construct()
    {
        $this->model = QuizAnswer::class;
        $this->translatableColumn = ['title'];
        $this->rules = [
            'title' => _RuleHelper::_Rule_Require,
            'correct'=>_RuleHelper::_Rule_Require,
            'orders'=>_RuleHelper::_Rule_Require,
            'quiz_id'=>_RuleHelper::_Rule_Require,
        ];
        $this->slug = true;
        $this->slugging = "title";
        $this->orderBy = 'orders';
        $this->slug = true;
        $this->columns = ['title', 'correct', 'orders', 'quiz_id'];
    }

}
