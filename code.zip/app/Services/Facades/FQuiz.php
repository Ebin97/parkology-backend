<?php


namespace App\Services\Facades;


use App\Helper\_RuleHelper as _RuleHelperAlias;
use App\Models\Quiz;
use App\Models\UserQuiz;
use App\Services\Interfaces\IQuiz;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use function Symfony\Component\HttpKernel\DataCollector\getCode;
use function Symfony\Component\HttpKernel\DataCollector\getMessage;

class FQuiz extends FBase implements IQuiz
{
    public function __construct()
    {
        $this->model = Quiz::class;
        $this->translatableColumn = ['title', 'slug'];
        $this->rules = [
            'title' => _RuleHelperAlias::_Rule_Require,
            'level' => _RuleHelperAlias::_Rule_Require,
            'active' => _RuleHelperAlias::_Rule_Require,
            'bonus' => _RuleHelperAlias::_Rule_Require,
            'start_time' => _RuleHelperAlias::_Rule_Require,
            'end_time' => _RuleHelperAlias::_Rule_Require,
        ];
        $this->unique = "slug";
        $this->slug = true;
        $this->slugging = "title";
        $this->orderBy = 'level';
        $this->columns = ['title', 'active', 'level', 'bonus', 'start_time', 'end_time'];
    }

    function solved(Request $request)
    {
        // TODO: Implement solved() method.
    }

    //Prepare level for the game
    function getLevel(Request $request)
    {
        try {
            $request->validate([
                'level' => _RuleHelperAlias::_Rule_Require . '|' . _RuleHelperAlias::_Rule_Number
            ]);
            $user = Auth::guard('api')->user();
            if ($user) {
                $quizzes = $this->getByLevel($request->input('level'));
                list($lost, $correct) = $this->checkLevelForUser($quizzes);
                if (count($lost) == 0 && count($correct) < count($quizzes)) {
                    return [$quizzes, _RuleHelperAlias::_AVAILABLE];
                }

                if (count($lost) == 0) {
                    return [[], _RuleHelperAlias::_SOLVED];
                }
                if (count($correct) < count($quizzes)) {
                    return [[], _RuleHelperAlias::_LOST];
                }
            }
            return [[], _RuleHelperAlias::_LOCKED];
        } catch (\Exception $exception) {
            throw new \Exception($exception->getMessage(), $exception->getCode());
        }
    }

    function checkLevelForUser($quizzes)
    {
        $wrong = [];
        $correct = [];
        foreach ($quizzes as $quiz) {
            $check = UserQuiz::query()->where([
                'quiz_id' => $quiz->id,
                'user_id' => Auth::id(),
            ])->first();
            if ($check) {
                if ($check->attempts >= 3) {
                    $wrong[] = $check;
                } else {
                    if ($check->Answer->correct) {
                        $correct[] = $check;
                    }
                }
            }
        }
        return [$wrong, $correct];
    }

    function checkLevel(Request $request)
    {
        // TODO: Implement checkLevel() method.
    }

    function getByLevel($level)
    {
        return Quiz::query()->where(['level' => $level])->get();
    }

    function getQuizIDsByLevel($level)
    {
        return Quiz::query()->where(['level' => $level])->pluck('id')->toArray();
    }
}
