<?php


namespace App\Services\Facades;


use App\Helper\_EmailHelper;
use App\Helper\_RuleHelper;
use App\Models\Contact;
use App\Models\Type;
use App\Models\User;
use App\Models\UserToken;
use App\Services\Interfaces\IUser;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Intervention\Image\Facades\Image;

class FUser extends FBase implements IUser
{

    public function __construct()
    {
        $this->model = User::class;
        $this->search = [];
        $this->hasUnique = true;
        $this->unique = "email";
        $this->hashing = true;
        $this->hashingColumn = "password";
        $this->encrypt = true;
        $this->verificationEmail = false;
        $this->encryptColumn = "password";
        $this->rules = [
            'first_name' => _RuleHelper::_Rule_Require,
            'last_name' => _RuleHelper::_Rule_Require,
            'password' => _RuleHelper::_Rule_Require,
            'speciality_id' => _RuleHelper::_Rule_Require,
            'type_id' => _RuleHelper::_Rule_Require,
            'email' => _RuleHelper::_Rule_Require . "|" . _RuleHelper::_Rule_Email,
            'city' => _RuleHelper::_Rule_Require,
            'work_place' => _RuleHelper::_Rule_Require,
        ];

        $this->columns = ['first_name', 'last_name', 'password', 'email', 'type_id', 'speciality_id', 'city', 'work_place'];
        $this->allColumns = ['first_name', 'last_name', 'password', 'speciality_id', 'phone', 'type_id', 'city', 'work_place'];
    }

    public function updateUser(Request $request, $id)
    {
        $rules = [
            'first_name' => _RuleHelper::_Rule_Require,
            'last_name' => _RuleHelper::_Rule_Require,
            'type_id' => _RuleHelper::_Rule_Require,
            'email' => _RuleHelper::_Rule_Require . "|" . _RuleHelper::_Rule_Email,
            'city' => _RuleHelper::_Rule_Require,
            'work_place' => _RuleHelper::_Rule_Require,
        ];
        $ex = $request->validate($rules);
        if (($ex instanceof ValidationException)) {
            throw new ValidationException($ex->validator);
        }
        $item = $this->getById($id);
        if ($item) {
            if (!$this->checkDuplicate($request, $id)) {
                return null;
            }
            if ($item->email != $request->email) {
                $email = new _EmailHelper();
                $email->sendVerification($item);
            }
            Log::error(json_encode($this->getAllColumn($request)));
            $item->update($this->getAllColumn($request));
            return $item;
        }
        return null;
    }


    public function validationAll(Request $request)
    {
        try {
            $request->validate($this->rules);
            return true;
        } catch (ValidationException $exception) {
            return $exception;
        }
    }


    public function getByEmail($email)
    {
        return User::query()->where([
            'email' => $email
        ])->first();
    }

    public function login(Request $request)
    {
        try {
            $rules = [
                'email' => _RuleHelper::_Rule_Require . "|" . _RuleHelper::_Rule_Email,
                'password' => _RuleHelper::_Rule_Require
            ];
            $request->validate($rules);
            $user = $this->getByEmail($request->input('email'));
            if (!$user) {
                return [null, false];
            }
            if (Hash::check($request->input('password'), $user->password)) {
                if ($user->document_verified) {
                    return [$user, true];
                }
                return [$user, false];
            }
            return [null, false];
        } catch (Exception $exception) {
            return null;
        }
    }

    public function updateAllUserPassword()
    {
        $users = User::all();
        foreach ($users as $user) {
            $user->update([
                'password' => Hash::make($user->email)
            ]);
        }
        return true;
    }

    public function uploadImage(Request $request, $user_id)
    {
        $user = $this->getById($user_id);
        if ($user && $user->Type->document == 1) {
            if ($request->hasFile('files')) {
                $image = $request->file('files');
                $destinationPath = public_path('storage/syndicates-thumb');
                $filename = "syndicate_" . $user_id . "_" . time() . "." . $image->getClientOriginalExtension();
                $imgFile = Image::make($image->getRealPath());
                $imgFile->resize(300, 150, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . '/' . $filename);
                $user->images()->create([
                    'url' => $filename,
                    'thumb_url' => $filename,
                    'mime_type' => $image->getMimeType(),
                    'type' => $filename,
                ]);
                return true;
            }
        }
        return false;
    }

    public function checkType(Request $request)
    {
        if ($request->has('type_id')) {
            $type = Type::query()->where('id', $request->type_id)->first();
            if ($type->document == 1) {
                return true;
            }
        }
        return false;
    }

    public function contact(Request $request)
    {
        try {

            $rules = [
                'email' => _RuleHelper::_Rule_Require . "|" . _RuleHelper::_Rule_Email,
                'full_name' => _RuleHelper::_Rule_Require,
                'message_text' => _RuleHelper::_Rule_Require
            ];

            $request->validate($rules);
            return Contact::query()->create([
                'full_name' => $request->input('full_name'),
                'email' => $request->input('email'),
                'message_text' => $request->input('message_text'),
                'user_id' => Auth::guard('api')->id()
            ]);
        } catch (Exception $exception) {
            throw new Exception($exception);
        }

    }

    public function forget(Request $request)
    {
        try {
            $rules = [
                'email' => _RuleHelper::_Rule_Require . "|" . _RuleHelper::_Rule_Email,
            ];

            $request->validate($rules);
            $user = $this->getByEmail($request->email);
            if (!$user) {
                return null;
            }
            $helper = new _EmailHelper();
            return $helper->sendResetPassword($user);
        } catch (Exception $exception) {
            throw new Exception($exception);
        }
    }

    public function checkToken($token)
    {
        return UserToken::query()->where([
            'token' => $token
        ])->where('expired_at', '>', Carbon::now())->first();

    }

}
