<?php

namespace App\Providers;

use App\Services\Facades\FBase;
use App\Services\Facades\FQuiz;
use App\Services\Facades\FRedeem;
use App\Services\Facades\FSetting;
use App\Services\Facades\FSpeciality;
use App\Services\Facades\FType;
use App\Services\Facades\FUser;
use App\Services\Facades\FUserQuiz;
use App\Services\Interfaces\IBase;
use App\Services\Interfaces\IQuiz;
use App\Services\Interfaces\IRedeem;
use App\Services\Interfaces\ISetting;
use App\Services\Interfaces\ISpeciality;
use App\Services\Interfaces\IType;
use App\Services\Interfaces\IUser;
use App\Services\Interfaces\IUserQuiz;
use Illuminate\Support\ServiceProvider;

class FacadeServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        $this->app->singleton(IBase::class, FBase::class);

        $this->app->singleton(IUser::class, FUser::class);

        $this->app->singleton(ISpeciality::class, FSpeciality::class);

        $this->app->singleton(ISetting::class, FSetting::class);

        $this->app->singleton(IType::class, FType::class);

        $this->app->singleton(IQuiz::class, FQuiz::class);

        $this->app->singleton(IUserQuiz::class, FUserQuiz::class);

        $this->app->singleton(IRedeem::class, FRedeem::class);

    }
}
