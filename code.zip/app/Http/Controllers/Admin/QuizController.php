<?php

namespace App\Http\Controllers\Admin;

use App\Helper\_MessageHelper;
use App\Http\Controllers\Controller;
use App\Http\Resources\BaseResource;
use App\Http\Resources\Admin\QuizResource;
use App\Services\Interfaces\IQuiz;
use Illuminate\Http\Request;

class QuizController extends Controller
{
    private $quiz;

    public function __construct(IQuiz $quiz)
    {
        $this->quiz = $quiz;
    }

    public function index(Request $request)
    {
        $res = $this->quiz->index($request);
        return QuizResource::paginable($res);
    }

    public function store(Request $request)
    {
        try {
            $res = $this->quiz->store($request);
            if ($res) {
                return QuizResource::create($res);
            }
            return BaseResource::returns(_MessageHelper::ErrorInRequest, 400);
        } catch (\Exception $exception) {
            return BaseResource::returns($exception->getMessage(), 400);
        }
    }

    public function show($id)
    {
        try {

            $res = $this->quiz->getById($id);
            if ($res) {
                return QuizResource::create($res);
            }
            return BaseResource::returns(_MessageHelper::NotExist, 400);
        } catch (\Exception $exception) {
            return BaseResource::returns($exception->getMessage(), 400);
        }
    }

    public function update(Request $request, $id)
    {
        try {

            $res = $this->quiz->update($request, $id);
            if ($res) {
                return BaseResource::ok();
            }
            return BaseResource::returns(_MessageHelper::NotExist, 400);
        } catch (\Exception $exception) {
            return BaseResource::returns($exception->getMessage(), 400);
        }
    }
    public function delete($id){
        try{
            $res = $this->quiz->delete($id);
            if ($res) {
                return BaseResource::ok();
            }
            return BaseResource::returns(_MessageHelper::NotExist, 400);
        } catch (\Exception $exception) {
            return BaseResource::returns($exception->getMessage(), 400);
        }
    }

}
