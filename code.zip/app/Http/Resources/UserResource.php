<?php

namespace App\Http\Resources;


use Carbon\Carbon;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;

class UserResource extends BaseResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'email' => $this->email,
            'speciality' => $this->Specialty()->first() ? $this->Specialty()->first()->name : null,
            'phone' => $this->phone,
            'work_place' => $this->work_place,
            'city' => $this->city,
            'type_id' =>$this->Type->id,
            'type' => $this->getType($this->Type, $this->language),
            'token' => $this->createToken('API Token')->accessToken,
            'language' => $this->language
        ];
    }

    function getType($type, $lang)
    {
        $language = "en";
        if ($type) {
            if ($lang == "both") {
                $language = "en";
            } else {
                $language = $lang?$lang:"en";
            }
            return [
                'id' => $type->id,
                'slug' => $type->slug,
                'name' => $type->getTranslation('name', $language),
            ];
        }
    }
}
