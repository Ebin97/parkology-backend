<?php

namespace App\Http\Resources\Admin;

use App\Http\Resources\BaseResource;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends BaseResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'email' => $this->email,
            'phone' => $this->phone,
            'work_place' => $this->work_place,
            'city' => $this->city,
            'type_id' => $this->Type->id,
            'type' => $this->getType($this->Type, $this->language),
            'language' => $this->language,
            'created_at' => date('Y-m-d h:iA',strtotime($this->created_at))
        ];
    }

    function getType($type, $lang)
    {
        $language = "en";
        if ($type) {
            if ($lang == "both") {
                $language = "en";
            } else {
                $language = $lang ? $lang : "en";
            }
            return $type->getTranslation('name', $language);

        }
    }
}
