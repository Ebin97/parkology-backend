<?php

namespace App\Http\Resources\Admin;

use App\Http\Resources\BaseResource;

class QuizResource extends BaseResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array|\Illuminate\Contracts\Support\Arrayable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'level' => $this->level,
            'slug' => $this->slug,
            'bonus' => $this->bonus,
            'active' => $this->active?"Active":"InActive",
            'start_time' => $this->start_time,
            'end_time' => $this->end_time,
            'created_at' => date('Y-m-d h:iA',strtotime($this->created_at))
        ];
    }

    public function getAnswers($answers)
    {
        $list = [];
        foreach ($answers as $answer) {
            $list[] = [
                'id' => $answer->id,
                'slug' => $answer->slug,
                'title' => $answer->title,
                'correct' => $answer->correct
            ];
        }
        return $list;
    }
}
