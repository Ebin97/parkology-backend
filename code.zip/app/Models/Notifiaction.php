<?php

namespace App\Models;

class Notifiaction extends Base
{
}
