<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuizAnswer extends Base
{
    public $translatable = ['title'];

    protected $fillable=['slug','title','correct','orders'];

    public function Quiz()
    {
        return $this->belongsTo(Quiz::class, 'quiz_id');
    }

    public function UserQuizzes()
    {
        return $this->hasMany(UserQuiz::class, 'answer_id');
    }

}
