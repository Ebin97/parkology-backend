<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserQuiz extends Model
{
    use HasFactory;
    protected $fillable = ["attempts", "quiz_id", "user_id", "answer_id","level"];

    public function Answer()
    {
        return $this->belongsTo(QuizAnswer::class, 'answer_id');
    }

    public function Quiz()
    {
        return $this->belongsTo(Quiz::class, 'quiz_id');
    }

    public function User()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

}
